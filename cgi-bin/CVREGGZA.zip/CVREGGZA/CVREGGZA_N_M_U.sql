-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.17-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para cvreggza
CREATE DATABASE IF NOT EXISTS `cvreggza` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci */;
USE `cvreggza`;

-- Volcando estructura para tabla cvreggza.mapa
CREATE TABLE IF NOT EXISTS `mapa` (
  `id_map` int(11) NOT NULL,
  `latitud_map` double NOT NULL DEFAULT 0,
  `longitud_map` double NOT NULL DEFAULT 0,
  `id_prod_map` int(11) NOT NULL DEFAULT 0,
  `localidad_map` varchar(50) COLLATE utf8_spanish_ci DEFAULT '0',
  `calle_seccion_map` varchar(50) COLLATE utf8_spanish_ci DEFAULT '0',
  `numero_dom_map` varchar(50) COLLATE utf8_spanish_ci DEFAULT '0',
  PRIMARY KEY (`id_map`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cvreggza.mapa: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mapa` DISABLE KEYS */;
INSERT INTO `mapa` (`id_map`, `latitud_map`, `longitud_map`, `id_prod_map`, `localidad_map`, `calle_seccion_map`, `numero_dom_map`) VALUES
	(0, 19.720606699999998, -97.2187754, 12, '12', '12', NULL),
	(1, 1, 1, 1, '1', '1', '1');
/*!40000 ALTER TABLE `mapa` ENABLE KEYS */;

-- Volcando estructura para tabla cvreggza.producto
CREATE TABLE IF NOT EXISTS `producto` (
  `id_prd` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_prd` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_prd` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Precio_cubo` float NOT NULL,
  `Precio_caja` float DEFAULT NULL,
  `Foto_prod` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_prd`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cvreggza.producto: ~15 rows (aproximadamente)
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` (`id_prd`, `nombre_prd`, `tipo_prd`, `Precio_cubo`, `Precio_caja`, `Foto_prod`) VALUES
	(1, 'Manzana verde', 'Manzana', 100, 170, ''),
	(2, '12', 'Manzana', 12, 12, 'default.png'),
	(3, 'Pera de agua', 'Pera', 75, 120, 'default.png'),
	(4, 'Pera de agua', 'Pera', 75, 120, 'default.png'),
	(5, 'Pera de agua', 'Pera', 75, 120, 'default.png'),
	(6, '', 'Manzana', 0, 0, '../img/Default.jpg'),
	(7, '', 'Manzana', 0, 0, '../img/Default.jpg'),
	(8, 'Pera de agua', 'Manzana', 0, 0, '../img/Default.jpg'),
	(9, 'Pera de agua', 'Manzana', 11, 112, '../img/Default.jpg'),
	(10, 'Pera de agua', 'Manzana', 123, 13, '../img/Default.jpg'),
	(11, 'Manzana roja', 'Manzana', 123, 13, '../img/Default.jpg'),
	(12, 'Chile de cera', 'Otro', 100, 200, '../img/Default.jpg'),
	(14, 'Durazno Prisco', 'Durazno', 70, 150, '../img/Default.jpg'),
	(15, 'Durazno Prisco', 'Durazno', 70, 140, '../../img/Productos/Default.jpg'),
	(16, 'Aguacatillo', 'Aguacate', 90, 150, '../../img/Productos/Default.jpg'),
	(17, 'Pera Mantequilla', 'Pera', 80, 140, '../../img/Productos/Default.jpg');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;

-- Volcando estructura para tabla cvreggza.publica
CREATE TABLE IF NOT EXISTS `publica` (
  `id_usu_pub` int(11) NOT NULL,
  `id_prod_pub` int(11) NOT NULL,
  `fecha_pub` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cvreggza.publica: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `publica` DISABLE KEYS */;
/*!40000 ALTER TABLE `publica` ENABLE KEYS */;

-- Volcando estructura para tabla cvreggza.registra
CREATE TABLE IF NOT EXISTS `registra` (
  `id_usu_reg` int(11) DEFAULT NULL,
  `id_prod_reg` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cvreggza.registra: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `registra` DISABLE KEYS */;
/*!40000 ALTER TABLE `registra` ENABLE KEYS */;

-- Volcando estructura para tabla cvreggza.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_u` int(10) NOT NULL AUTO_INCREMENT,
  `nombre_u` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellidos_u` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `correo_u` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `cont_u` varchar(12) COLLATE utf8mb4_spanish_ci NOT NULL,
  `cp_u` varchar(18) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `edad_u` int(2) NOT NULL,
  `tel_u` bigint(20) NOT NULL DEFAULT 0,
  `dom_u` varchar(50) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `foto_u` varchar(200) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `tipo_u` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id_u`),
  UNIQUE KEY `tel_u` (`tel_u`),
  UNIQUE KEY `correo_u` (`correo_u`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci ROW_FORMAT=DYNAMIC;

-- Volcando datos para la tabla cvreggza.usuario: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`id_u`, `nombre_u`, `apellidos_u`, `correo_u`, `cont_u`, `cp_u`, `edad_u`, `tel_u`, `dom_u`, `foto_u`, `tipo_u`) VALUES
	(1, 'Saul', 'Mendez', 'SaulM@mail.com', '827ccb0eea8a', '12345', 44, 2261153901, 'Sección Benito Juárez No.2', 'miu.png', 'Comprador');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
