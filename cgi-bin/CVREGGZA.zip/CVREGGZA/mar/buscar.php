<!DOCTYPE html>
<html>
<head>
	<title>BUSCAR</title>
	<link rel="stylesheet" href="css/Estilo.css">
	<script src="User/js/jquery-3.6.0.min.js"></script>
</head>
<body>
<!--<?php include "php/navbar.php"; ?>-->
<div class="container">
<div class="row">
<div class="col-md-12">
		<h2>BUSCAR</h2>


<?php include "User/script/Prod/Buscar_prods.php"; ?>
</div>
</div>
</div>

 <script src="./User/js/jquery-3.6.0.min.js"></script>
</body>
</html>


