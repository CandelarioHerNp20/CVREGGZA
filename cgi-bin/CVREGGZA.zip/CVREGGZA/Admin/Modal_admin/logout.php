<html>
    <div class="modal" tabindex="-1" id="modal_logout">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">Iniciar</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body p-5"> 
        <form  method="post" id="cerar_sesion">
            <p> ¿Realmente deseas cerrar tu sesión?</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" id="cerrar_logouts" data-bs-dismiss="modal">No</button>
            <button type="button" id="logout" class="btn btn-primary" data-bs-dismiss="modal">Si</button>
            </form >
        </div>
        </div>
    </div>
    </div>
</html>